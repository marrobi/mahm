class NotAuthorizedError(Exception):
    """Exception raised for unauthorized access attempts."""
    pass
