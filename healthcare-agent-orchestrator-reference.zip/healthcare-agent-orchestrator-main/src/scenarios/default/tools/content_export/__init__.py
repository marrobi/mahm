# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .content_export import create_plugin

__all__ = ["create_plugin"]
