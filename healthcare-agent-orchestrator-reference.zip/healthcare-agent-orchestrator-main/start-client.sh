#!/bin/bash
# Helper script to start the demo client from the root directory
echo "Starting the demo client..."
cd democlient && npm start 